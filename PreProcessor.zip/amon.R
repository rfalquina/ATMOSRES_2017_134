amon <- function(rt,n){
  #
  # extraemos los 20 valores de cada mes y promediamos
  #
  rm(prTMP)
  prTMP <- raster(rt,n)
  #
  for (i in 1:19) {
    prTMP <- addLayer(prTMP, raster(rt,12*i+n))
  }
  prAMON <- mean(prTMP)
  #
}