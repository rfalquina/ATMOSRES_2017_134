#
#
setwd("F:/Tesis/Datos IPCC AR5 rcp85/PreProcessor")
#
# leo los datos climaticos del s. XX y del s. XXI
# utilizo los resultados del modelo MPI-ESM-MR del Instituto Max Planck
# en formato netCDF
#
library("ncdf4")
library("raster")
#
# Lectura de datos con RASTER
# Datos de la simulacion del s. XXI
#
# Mascara tierra-agua
#
rt_sftlf <- raster("F:/Tesis/Datos IPCC AR5 rcp85/sftlf_fx_MPI-ESM-MR_rcp85_r0i0p0.nc", varname="sftlf", lvar=)
#plot(rt_sftlf)
#
# Precipitacion y temperatura a 2m
#
rt_pr <- brick("F:/Tesis/Datos IPCC AR5 rcp85/pr_Amon_MPI-ESM-MR_rcp85_r1i1p1_200601-210012.nc", varname="pr")
rt_tas <- brick("F:/Tesis/Datos IPCC AR5 rcp85/tas_Amon_MPI-ESM-MR_rcp85_r1i1p1_200601-210012.nc", varname="tas")
rt_pr2 <- brick("F:/Tesis/Datos IPCC AR5 rcp85/pr_Amon_CSIRO-Mk3-6-0_rcp85_r1i1p1_200601-210012.nc", varname="pr")
rt_tas2 <- brick("F:/Tesis/Datos IPCC AR5 rcp85/tas_Amon_CSIRO-Mk3-6-0_rcp85_r1i1p1_200601-210012.nc", varname="tas")
rt_pr3 <- brick("F:/Tesis/Datos IPCC AR5 rcp85/pr_Amon_CCSM4_rcp85_r1i1p1_200601-210012.nc", varname="pr")
rt_tas3 <- brick("F:/Tesis/Datos IPCC AR5 rcp85/tas_Amon_CCSM4_rcp85_r1i1p1_200601-210012.nc", varname="tas")
#
# Los datos del modelo GFDL-CM3 están repartidos en varios ficheros
# que hay que leer y agrupar
#
rt_pr4 <- brick("F:/Tesis/Datos IPCC AR5 rcp85/pr_Amon_GFDL-CM3_rcp85_r1i1p1_208101-208512.nc", varname="pr")
rt_tas4 <- brick("F:/Tesis/Datos IPCC AR5 rcp85/tas_Amon_GFDL-CM3_rcp85_r1i1p1_208101-208512.nc", varname="tas")
rt_pr4a<- brick("F:/Tesis/Datos IPCC AR5 rcp85/pr_Amon_GFDL-CM3_rcp85_r1i1p1_208601-209012.nc", varname="pr")
rt_tas4a <- brick("F:/Tesis/Datos IPCC AR5 rcp85/tas_Amon_GFDL-CM3_rcp85_r1i1p1_208601-209012.nc", varname="tas")
rt_pr4 <- stack(rt_pr4,rt_pr4a)
rt_tas4 <- stack(rt_tas4,rt_tas4a)
rt_pr4b<- brick("F:/Tesis/Datos IPCC AR5 rcp85/pr_Amon_GFDL-CM3_rcp85_r1i1p1_209101-209512.nc", varname="pr")
rt_tas4b <- brick("F:/Tesis/Datos IPCC AR5 rcp85/tas_Amon_GFDL-CM3_rcp85_r1i1p1_209101-209512.nc", varname="tas")
rt_pr4 <- stack(rt_pr4,rt_pr4b)
rt_tas4 <- stack(rt_tas4,rt_tas4b)
rt_pr4c<- brick("F:/Tesis/Datos IPCC AR5 rcp85/pr_Amon_GFDL-CM3_rcp85_r1i1p1_209601-210012.nc", varname="pr")
rt_tas4c <- brick("F:/Tesis/Datos IPCC AR5 rcp85/tas_Amon_GFDL-CM3_rcp85_r1i1p1_209601-210012.nc", varname="tas")
rt_pr4 <- stack(rt_pr4,rt_pr4c)
rt_tas4 <- stack(rt_tas4,rt_tas4c)
#
rt_pr5 <- brick("F:/Tesis/Datos IPCC AR5 rcp85/pr_Amon_GISS-E2-R_rcp85_r1i1p1_207601-210012.nc", varname="pr")
rt_tas5 <- brick("F:/Tesis/Datos IPCC AR5 rcp85/tas_Amon_GISS-E2-R_rcp85_r1i1p1_207601-210012.nc", varname="tas")
#
# Los datos del modelo HadGEM2-ES (Met Office Hadley Centre UK) en un fichero llegan a diciembre 2099
# cuando el resto de modelos los tengo hasta diciembre de 2100. Necesito un fichero adicional
# para añadir los doce meses de 2100. Este nuevo fichero repite diciembre de 2099
#
rt_pr6 <- brick("F:/Tesis/Datos IPCC AR5 rcp85/pr_Amon_HadGEM2-ES_rcp85_r1i1p1_208012-209912.nc", varname="pr")
rt_tas6 <- brick("F:/Tesis/Datos IPCC AR5 rcp85/tas_Amon_HadGEM2-ES_rcp85_r1i1p1_208012-209912.nc", varname="tas")
rt_pr6 <- dropLayer(rt_pr6,c(1))
rt_tas6 <- dropLayer(rt_tas6,c(1))
rt_pr6a <- brick("F:/Tesis/Datos IPCC AR5 rcp85/pr_Amon_HadGEM2-ES_rcp85_r1i1p1_209912-212411.nc", varname="pr")
rt_tas6a <- brick("F:/Tesis/Datos IPCC AR5 rcp85/tas_Amon_HadGEM2-ES_rcp85_r1i1p1_209912-212411.nc", varname="tas")
rt_pr6a <- dropLayer(rt_pr6a,c(1))
rt_tas6a <- dropLayer(rt_tas6a,c(1))
rt_pr6a <- dropLayer(rt_pr6a,c(13:299))
rt_tas6a <- dropLayer(rt_tas6a,c(13:299))
rt_pr6 <- stack(rt_pr6,rt_pr6a)
rt_tas6 <- stack(rt_tas6,rt_tas6a)
#
rt_pr7 <- brick("F:/Tesis/Datos IPCC AR5 rcp85/pr_Amon_IPSL-CM5A-LR_rcp85_r1i1p1_200601-230012.nc", varname="pr")
rt_tas7 <- brick("F:/Tesis/Datos IPCC AR5 rcp85/tas_Amon_IPSL-CM5A-LR_rcp85_r1i1p1_200601-230012.nc", varname="tas")
#
rt_pr8 <- brick("F:/Tesis/Datos IPCC AR5 rcp85/pr_Amon_MRI-CGCM3_rcp85_r1i1p1_200601-210012.nc", varname="pr")
rt_tas8 <- brick("F:/Tesis/Datos IPCC AR5 rcp85/tas_Amon_MRI-CGCM3_rcp85_r1i1p1_200601-210012.nc", varname="tas")
#
# eliminamos todos los datos de 2006 a 2080
# dropLayer convierte los RasterBrick en RasterStack 
# quedan 240 layers = 20 agnos * 12 meses
#
rt_pr <- dropLayer(rt_pr,c(1:900))
rt_tas <- dropLayer(rt_tas,c(1:900))
rt_pr2 <- dropLayer(rt_pr2,c(1:900))
rt_tas2 <- dropLayer(rt_tas2,c(1:900))
rt_pr3 <- dropLayer(rt_pr3,c(1:900))
rt_tas3 <- dropLayer(rt_tas3,c(1:900))
rt_pr3 <- resample(rt_pr3, rt_pr, method='bilinear')
rt_tas3 <- resample(rt_tas3, rt_tas, method='bilinear')
#
# Los datos del modelo GFDL-CM3 tienen ya los años que necesitamos
# pero una resolución de 90x144 celdas, cuando estamos trabajando
# con 92x192 celdas. Desdoblo en las dos direcciones y resampleo
# para igualar la resolución y los rangos geográficos
#
rt_pr4 <- disaggregate(rt_pr4, fact = c(2,2), method = 'bilinear')
rt_tas4 <- disaggregate(rt_tas4, fact = c(2,2), method = 'bilinear')
rt_pr4 <- resample(rt_pr4,rt_pr, method="bilinear")
rt_tas4 <- resample(rt_tas4,rt_tas, method="bilinear")
#
# Los datos del modelo GISS-E2-R cubren de 2076 a 2100, hay que
# eliminar los primeros 60 'layers'. Además tiene una resolución 
# de 90x144 celdas, cuando estamos trabajando con 92x192 celdas.
# Desdoblo en las dos direcciones y resampleo
# para igualar la resolución y los rangos geográficos
#
rt_pr5 <- dropLayer(rt_pr5,c(1:60))
rt_tas5 <- dropLayer(rt_tas5,c(1:60))
rt_pr5 <- disaggregate(rt_pr5, fact = c(2,2), method = 'bilinear')
rt_tas5 <- disaggregate(rt_tas5, fact = c(2,2), method = 'bilinear')
rt_pr5 <- resample(rt_pr5,rt_pr, method="bilinear")
rt_tas5 <- resample(rt_tas5,rt_tas, method="bilinear")
#
# Los datos del modelo HadGEM2-ES tienen una resolucion de 145x192
# así que basta con resamplear para igualar la resolución 
# y los rangos geográficos
#
rt_pr6 <- resample(rt_pr6,rt_pr, method="bilinear")
rt_tas6 <- resample(rt_tas6,rt_tas, method="bilinear")
#
# Los datos del modelo IPSL-CM5A-LR llegan hasta el año 2300
# hay que eliminar datos de 2006-2080 y 2101-2300.
# Además, en latitud solo tiene 96 celdas. Como estamos trabajando
# con 192 celdas las desdoblamos y resampleamos para igualar los rangos espaciales
# Solo para este dataset es necesario extender explicitamente el rango geográfico
# de longitud 358.125 hasta 359.0625, si no resample daba problemas y deja las
# ultimas celdas en longitud 359.625 sin valores 
#
rt_pr7 <- dropLayer(rt_pr7,c(1:900))
rt_tas7 <- dropLayer(rt_tas7,c(1:900))
rt_pr7 <- dropLayer(rt_pr7,c(241:2640))
rt_tas7 <- dropLayer(rt_tas7,c(241:2640))
rt_pr7 <- disaggregate(rt_pr7, fact = c(2,1), method = 'bilinear')
rt_tas7 <- disaggregate(rt_tas7, fact = c(2,1), method = 'bilinear')
rt_pr7 <- extend(rt_pr7,rt_pr)
rt_tas7 <- extend(rt_tas7,rt_tas)
rt_pr7 <- resample(rt_pr7,rt_pr, method="bilinear")
rt_tas7 <- resample(rt_tas7,rt_tas, method="bilinear")
#
# Los datos del modelo MRI-CGCM3 tienen una resolucion de 160x320 celdas
# basta con resamplearlo a 96x192. Previamente eliminamos los años 2006-2080
#
rt_pr8 <- dropLayer(rt_pr8,c(1:900))
rt_tas8 <- dropLayer(rt_tas8,c(1:900))
rt_pr8 <- resample(rt_pr8,rt_pr, method="bilinear")
rt_tas8 <- resample(rt_tas8,rt_tas, method="bilinear")
#
#compareRaster(rt_pr, rt_pr2)
#
# Datos de la simulacion historica 1850-2006
#
rt_pr.hist <- brick("F:/Tesis/Datos IPCC AR5 rcp85/pr_Amon_MPI-ESM-MR_historical_r1i1p1_185001-200512.nc", varname="pr")
rt_tas.hist <- brick("F:/Tesis/Datos IPCC AR5 rcp85/tas_Amon_MPI-ESM-MR_historical_r1i1p1_185001-200512.nc", varname="tas")
rt_pr2.hist <- brick("F:/Tesis/Datos IPCC AR5 rcp85/pr_Amon_CSIRO-Mk3-6-0_historical_r1i1p1_185001-200512.nc", varname="pr")
rt_tas2.hist <- brick("F:/Tesis/Datos IPCC AR5 rcp85/tas_Amon_CSIRO-Mk3-6-0_historical_r1i1p1_185001-200512.nc", varname="tas")
rt_pr3.hist <- brick("F:/Tesis/Datos IPCC AR5 rcp85/pr_Amon_CCSM4_historical_r1i1p1_185001-200512.nc", varname="pr")
rt_tas3.hist <- brick("F:/Tesis/Datos IPCC AR5 rcp85/tas_Amon_CCSM4_historical_r1i1p1_185001-200512.nc", varname="tas")
#
#
# Los datos del modelo GFDL-CM3 están repartidos en varios ficheros
# que hay que leer y agrupar
#
rt_pr4.hist <- brick("F:/Tesis/Datos IPCC AR5 rcp85/pr_Amon_GFDL-CM3_historical_r1i1p1_198001-198412.nc", varname="pr")
rt_tas4.hist <- brick("F:/Tesis/Datos IPCC AR5 rcp85/tas_Amon_GFDL-CM3_historical_r1i1p1_198001-198412.nc", varname="tas")
rt_pr4a.hist <- brick("F:/Tesis/Datos IPCC AR5 rcp85/pr_Amon_GFDL-CM3_historical_r1i1p1_198501-198912.nc", varname="pr")
rt_tas4a.hist <- brick("F:/Tesis/Datos IPCC AR5 rcp85/tas_Amon_GFDL-CM3_historical_r1i1p1_198501-198912.nc", varname="tas")
rt_pr4.hist <- stack(rt_pr4.hist,rt_pr4a.hist)
rt_tas4.hist <- stack(rt_tas4.hist,rt_tas4a.hist)
rt_pr4b.hist <- brick("F:/Tesis/Datos IPCC AR5 rcp85/pr_Amon_GFDL-CM3_historical_r1i1p1_199001-199412.nc", varname="pr")
rt_tas4b.hist <- brick("F:/Tesis/Datos IPCC AR5 rcp85/tas_Amon_GFDL-CM3_historical_r1i1p1_199001-199412.nc", varname="tas")
rt_pr4.hist <- stack(rt_pr4.hist,rt_pr4b.hist)
rt_tas4.hist <- stack(rt_tas4.hist,rt_tas4b.hist)
rt_pr4c.hist <- brick("F:/Tesis/Datos IPCC AR5 rcp85/pr_Amon_GFDL-CM3_historical_r1i1p1_199501-199912.nc", varname="pr")
rt_tas4c.hist <- brick("F:/Tesis/Datos IPCC AR5 rcp85/tas_Amon_GFDL-CM3_historical_r1i1p1_199501-199912.nc", varname="tas")
rt_pr4.hist <- stack(rt_pr4.hist,rt_pr4c.hist)
rt_tas4.hist <- stack(rt_tas4.hist,rt_tas4c.hist)
#
rt_pr5.hist <- brick("F:/Tesis/Datos IPCC AR5 rcp85/pr_Amon_GISS-E2-R_historical_r1i1p1_197601-200012.nc", varname="pr")
rt_tas5.hist <- brick("F:/Tesis/Datos IPCC AR5 rcp85/tas_Amon_GISS-E2-R_historical_r1i1p1_197601-200012.nc", varname="tas")
#
# Los datos del modelo HadGEM2-ES (Met Office Hadley Centre UK) en un fichero llegan a diciembre 2099
# cuando el resto de modelos los tengo hasta diciembre de 2100. Necesito un fichero adicional
# para añadir los doce meses de 2100. Este nuevo fichero repite diciembre de 2099
#
rt_pr6.hist <- brick("F:/Tesis/Datos IPCC AR5 rcp85/pr_Amon_HadGEM2-ES_historical_r1i1p1_195912-198411.nc", varname="pr")
rt_tas6.hist <- brick("F:/Tesis/Datos IPCC AR5 rcp85/tas_Amon_HadGEM2-ES_historical_r1i1p1_195912-198411.nc", varname="tas")
rt_pr6.hist <- dropLayer(rt_pr6.hist,c(1:241))
rt_tas6.hist <- dropLayer(rt_tas6.hist,c(1:241))
rt_pr6a.hist <- brick("F:/Tesis/Datos IPCC AR5 rcp85/pr_Amon_HadGEM2-ES_historical_r1i1p1_198412-200511.nc", varname="pr")
rt_tas6a.hist <- brick("F:/Tesis/Datos IPCC AR5 rcp85/tas_Amon_HadGEM2-ES_historical_r1i1p1_198412-200511.nc", varname="tas")
rt_pr6a.hist <- dropLayer(rt_pr6a.hist,c(182:252))
rt_tas6a.hist <- dropLayer(rt_tas6a.hist,c(182:252))
rt_pr6.hist <- stack(rt_pr6.hist,rt_pr6a.hist)
rt_tas6.hist <- stack(rt_tas6.hist,rt_tas6a.hist)
#
rt_pr7.hist <- brick("F:/Tesis/Datos IPCC AR5 rcp85/pr_Amon_IPSL-CM5A-LR_historical_r1i1p1_185001-200512.nc", varname="pr")
rt_tas7.hist <- brick("F:/Tesis/Datos IPCC AR5 rcp85/tas_Amon_IPSL-CM5A-LR_historical_r1i1p1_185001-200512.nc", varname="tas")
#
rt_pr8.hist <- brick("F:/Tesis/Datos IPCC AR5 rcp85/pr_Amon_MRI-CGCM3_historical_r1i1p1_185001-200512.nc", varname="pr")
rt_tas8.hist <- brick("F:/Tesis/Datos IPCC AR5 rcp85/tas_Amon_MRI-CGCM3_historical_r1i1p1_185001-200512.nc", varname="tas")
#
# eliminamos todos los datos de 1850 a 1979 (incl.) y de 2000 (incl.) a 2006
# dropLayer convierte los RasterBrick en RasterStack 
# quedan 240 layers = 20 agnos * 12 meses (1980-1999)
#
rt_pr.hist <- dropLayer(rt_pr.hist,c(1:1560))
rt_tas.hist <- dropLayer(rt_tas.hist,c(1:1560))
rt_pr2.hist <- dropLayer(rt_pr2.hist,c(1:1560))
rt_tas2.hist <- dropLayer(rt_tas2.hist,c(1:1560))
rt_pr3.hist <- dropLayer(rt_pr3.hist,c(1:1560))
rt_tas3.hist <- dropLayer(rt_tas3.hist,c(1:1560))
rt_pr.hist <- dropLayer(rt_pr.hist,c(241:312))
rt_tas.hist <- dropLayer(rt_tas.hist,c(241:312))
rt_pr2.hist <- dropLayer(rt_pr2.hist,c(241:312))
rt_tas2.hist <- dropLayer(rt_tas2.hist,c(241:312))
rt_pr3.hist <- dropLayer(rt_pr3.hist,c(241:312))
rt_tas3.hist <- dropLayer(rt_tas3.hist,c(241:312))
rt_pr3.hist <- resample(rt_pr3.hist, rt_pr.hist, method='bilinear')
rt_tas3.hist <- resample(rt_tas3.hist, rt_tas.hist, method='bilinear')
#
# Los datos del modelo GFDL-CM3 tienen ya los años que necesitamos
# pero una resolución de 90x144 celdas, cuando estamos trabajando
# con 92x192 celdas. Desdoblo en las dos direcciones y resampleo
# para igualar la resolución y los rangos geográficos
#
rt_pr4.hist <- disaggregate(rt_pr4.hist, fact = c(2,2), method = 'bilinear')
rt_tas4.hist <- disaggregate(rt_tas4.hist, fact = c(2,2), method = 'bilinear')
rt_pr4.hist <- resample(rt_pr4.hist,rt_pr.hist, method="bilinear")
rt_tas4.hist <- resample(rt_tas4.hist,rt_tas.hist, method="bilinear")
#
# Los datos del modelo GISS-E2-R cubren de 1976 a 2000 (incluidos), hay que
# eliminar los primeros 48 'layers' y los últimos 12. Además tiene una resolución 
# de 90x144 celdas, cuando estamos trabajando con 92x192 celdas.
# Desdoblo en las dos direcciones y resampleo
# para igualar la resolución y los rangos geográficos
#
rt_pr5.hist <- dropLayer(rt_pr5.hist,c(1:48))
rt_tas5.hist <- dropLayer(rt_tas5.hist,c(1:48))
rt_pr5.hist <- dropLayer(rt_pr5.hist,c(241:252))
rt_tas5.hist <- dropLayer(rt_tas5.hist,c(241:252))
rt_pr5.hist <- disaggregate(rt_pr5.hist, fact = c(2,2), method = 'bilinear')
rt_tas5.hist <- disaggregate(rt_tas5.hist, fact = c(2,2), method = 'bilinear')
rt_pr5.hist <- resample(rt_pr5.hist,rt_pr.hist, method="bilinear")
rt_tas5.hist <- resample(rt_tas5.hist,rt_tas.hist, method="bilinear")
#
# Los datos del modelo HadGEM2-ES tienen una resolucion de 145x192
# así que basta con resamplear para igualar la resolución 
# y los rangos geográficos
#
rt_pr6.hist <- resample(rt_pr6.hist,rt_pr.hist, method="bilinear")
rt_tas6.hist <- resample(rt_tas6.hist,rt_tas.hist, method="bilinear")
#
# En el modelo IPSL-CM5A-LR 
# hay que eliminar datos de 1850-1979 (incl.) y 2000 (incl.) - 2005.
# Además, en latitud solo tiene 96 celdas. Como estamos trabajando
# con 192 celdas las desdoblamos y resampleamos para igualar los rangos espaciales
# Solo para este dataset es necesario extender explicitamente el rango geográfico
# de longitud 358.125 hasta 359.0625, si no resample daba problemas y deja las
# ultimas celdas en longitud 359.625 sin valores 
#
rt_pr7.hist <- dropLayer(rt_pr7.hist,c(1:1560))
rt_tas7.hist <- dropLayer(rt_tas7.hist,c(1:1560))
rt_pr7.hist <- dropLayer(rt_pr7.hist,c(241:312))
rt_tas7.hist <- dropLayer(rt_tas7.hist,c(241:312))
rt_pr7.hist <- disaggregate(rt_pr7.hist, fact = c(2,1), method = 'bilinear')
rt_tas7.hist <- disaggregate(rt_tas7.hist, fact = c(2,1), method = 'bilinear')
rt_pr7.hist <- extend(rt_pr7.hist,rt_pr.hist)
rt_tas7.hist <- extend(rt_tas7.hist,rt_tas.hist)
rt_pr7.hist <- resample(rt_pr7.hist,rt_pr.hist, method="bilinear")
rt_tas7.hist <- resample(rt_tas7.hist,rt_tas.hist, method="bilinear")
#
# Los datos del modelo MRI-CGCM3 tienen una resolucion de 160x320 celdas
# basta con resamplearlo a 96x192. Previamente eliminamos los años
# 1850-1979 (incl.) y 2000 (incl.) - 2005.
#
rt_pr8.hist <- dropLayer(rt_pr8.hist,c(1:1560))
rt_tas8.hist <- dropLayer(rt_tas8.hist,c(1:1560))
rt_pr8.hist <- dropLayer(rt_pr8.hist,c(241:312))
rt_tas8.hist <- dropLayer(rt_tas8.hist,c(241:312))
rt_pr8.hist <- resample(rt_pr8.hist,rt_pr.hist, method="bilinear")
rt_tas8.hist <- resample(rt_tas8.hist,rt_tas.hist, method="bilinear")
#
#
# para la precipitacion extraemos los 20 valores de cada mes y promediamos
#
# amon(r,n) extrae 20 valores del raster r para el mes n (n,n+12,n+24,...)
# r debe tener 240 meses, o 20 annos
#
prJAN <- mean(addLayer(amon(rt_pr,1),amon(rt_pr2,1),amon(rt_pr3,1),amon(rt_pr4,1),amon(rt_pr5,1),amon(rt_pr6,1),amon(rt_pr7,1),amon(rt_pr8,1)))
prFEB <- mean(addLayer(amon(rt_pr,2),amon(rt_pr2,2),amon(rt_pr3,2),amon(rt_pr4,2),amon(rt_pr5,2),amon(rt_pr6,2),amon(rt_pr7,2),amon(rt_pr8,2)))
prMAR <- mean(addLayer(amon(rt_pr,3),amon(rt_pr2,3),amon(rt_pr3,3),amon(rt_pr4,3),amon(rt_pr5,3),amon(rt_pr6,3),amon(rt_pr7,3),amon(rt_pr8,3)))
prAPR <- mean(addLayer(amon(rt_pr,4),amon(rt_pr2,4),amon(rt_pr3,4),amon(rt_pr4,4),amon(rt_pr5,4),amon(rt_pr6,4),amon(rt_pr7,4),amon(rt_pr8,4)))
prMAY <- mean(addLayer(amon(rt_pr,5),amon(rt_pr2,5),amon(rt_pr3,5),amon(rt_pr4,5),amon(rt_pr5,5),amon(rt_pr6,5),amon(rt_pr7,5),amon(rt_pr8,5)))
prJUN <- mean(addLayer(amon(rt_pr,6),amon(rt_pr2,6),amon(rt_pr3,6),amon(rt_pr4,6),amon(rt_pr5,6),amon(rt_pr6,6),amon(rt_pr7,6),amon(rt_pr8,6)))
prJUL <- mean(addLayer(amon(rt_pr,7),amon(rt_pr2,7),amon(rt_pr3,7),amon(rt_pr4,7),amon(rt_pr5,7),amon(rt_pr6,7),amon(rt_pr7,7),amon(rt_pr8,7)))
prAUG <- mean(addLayer(amon(rt_pr,8),amon(rt_pr2,8),amon(rt_pr3,8),amon(rt_pr4,8),amon(rt_pr5,8),amon(rt_pr6,8),amon(rt_pr7,8),amon(rt_pr8,8)))
prSEP <- mean(addLayer(amon(rt_pr,9),amon(rt_pr2,9),amon(rt_pr3,9),amon(rt_pr4,9),amon(rt_pr5,9),amon(rt_pr6,9),amon(rt_pr7,9),amon(rt_pr8,9)))
prOCT <- mean(addLayer(amon(rt_pr,10),amon(rt_pr2,10),amon(rt_pr3,10),amon(rt_pr4,10),amon(rt_pr5,10),amon(rt_pr6,10),amon(rt_pr7,10),amon(rt_pr8,10)))
prNOV <- mean(addLayer(amon(rt_pr,11),amon(rt_pr2,11),amon(rt_pr3,11),amon(rt_pr4,11),amon(rt_pr5,11),amon(rt_pr6,11),amon(rt_pr7,11),amon(rt_pr8,11)))
prDEC <- mean(addLayer(amon(rt_pr,12),amon(rt_pr2,12),amon(rt_pr3,12),amon(rt_pr4,12),amon(rt_pr5,12),amon(rt_pr6,12),amon(rt_pr7,12),amon(rt_pr8,12)))
#
prJAN.hist <- mean(addLayer(amon(rt_pr.hist,1),amon(rt_pr2.hist,1),amon(rt_pr3.hist,1),amon(rt_pr4.hist,1),amon(rt_pr5.hist,1),amon(rt_pr6.hist,1),amon(rt_pr7.hist,1),amon(rt_pr8.hist,1)))
prFEB.hist <- mean(addLayer(amon(rt_pr.hist,2),amon(rt_pr2.hist,2),amon(rt_pr3.hist,2),amon(rt_pr4.hist,2),amon(rt_pr5.hist,2),amon(rt_pr6.hist,2),amon(rt_pr7.hist,2),amon(rt_pr8.hist,2)))
prMAR.hist <- mean(addLayer(amon(rt_pr.hist,3),amon(rt_pr2.hist,3),amon(rt_pr3.hist,3),amon(rt_pr4.hist,3),amon(rt_pr5.hist,3),amon(rt_pr6.hist,3),amon(rt_pr7.hist,3),amon(rt_pr8.hist,3)))
prAPR.hist <- mean(addLayer(amon(rt_pr.hist,4),amon(rt_pr2.hist,4),amon(rt_pr3.hist,4),amon(rt_pr4.hist,4),amon(rt_pr5.hist,4),amon(rt_pr6.hist,4),amon(rt_pr7.hist,4),amon(rt_pr8.hist,4)))
prMAY.hist <- mean(addLayer(amon(rt_pr.hist,5),amon(rt_pr2.hist,5),amon(rt_pr3.hist,5),amon(rt_pr4.hist,5),amon(rt_pr5.hist,5),amon(rt_pr6.hist,5),amon(rt_pr7.hist,5),amon(rt_pr8.hist,5)))
prJUN.hist <- mean(addLayer(amon(rt_pr.hist,6),amon(rt_pr2.hist,6),amon(rt_pr3.hist,6),amon(rt_pr4.hist,6),amon(rt_pr5.hist,6),amon(rt_pr6.hist,6),amon(rt_pr7.hist,6),amon(rt_pr8.hist,6)))
prJUL.hist <- mean(addLayer(amon(rt_pr.hist,7),amon(rt_pr2.hist,7),amon(rt_pr3.hist,7),amon(rt_pr4.hist,7),amon(rt_pr5.hist,7),amon(rt_pr6.hist,7),amon(rt_pr7.hist,7),amon(rt_pr8.hist,7)))
prAUG.hist <- mean(addLayer(amon(rt_pr.hist,8),amon(rt_pr2.hist,8),amon(rt_pr3.hist,8),amon(rt_pr4.hist,8),amon(rt_pr5.hist,8),amon(rt_pr6.hist,8),amon(rt_pr7.hist,8),amon(rt_pr8.hist,8)))
prSEP.hist <- mean(addLayer(amon(rt_pr.hist,9),amon(rt_pr2.hist,9),amon(rt_pr3.hist,9),amon(rt_pr4.hist,9),amon(rt_pr5.hist,9),amon(rt_pr6.hist,9),amon(rt_pr7.hist,9),amon(rt_pr8.hist,9)))
prOCT.hist <- mean(addLayer(amon(rt_pr.hist,10),amon(rt_pr2.hist,10),amon(rt_pr3.hist,10),amon(rt_pr4.hist,10),amon(rt_pr5.hist,10),amon(rt_pr6.hist,10),amon(rt_pr7.hist,10),amon(rt_pr8.hist,10)))
prNOV.hist <- mean(addLayer(amon(rt_pr.hist,11),amon(rt_pr2.hist,11),amon(rt_pr3.hist,11),amon(rt_pr4.hist,11),amon(rt_pr5.hist,11),amon(rt_pr6.hist,11),amon(rt_pr7.hist,11),amon(rt_pr8.hist,11)))
prDEC.hist <- mean(addLayer(amon(rt_pr.hist,12),amon(rt_pr2.hist,12),amon(rt_pr3.hist,12),amon(rt_pr4.hist,12),amon(rt_pr5.hist,12),amon(rt_pr6.hist,12),amon(rt_pr7.hist,12),amon(rt_pr8.hist,12)))
#
# para la temperatura a 2m extraemos los 20 valores de cada mes y promediamos
#
tasJAN <- mean(addLayer(amon(rt_tas,1),amon(rt_tas2,1),amon(rt_tas3,1),amon(rt_tas4,1),amon(rt_tas5,1),amon(rt_tas6,1),amon(rt_tas7,1),amon(rt_tas8,1)))
tasFEB <- mean(addLayer(amon(rt_tas,2),amon(rt_tas2,2),amon(rt_tas3,2),amon(rt_tas4,2),amon(rt_tas5,2),amon(rt_tas6,2),amon(rt_tas7,2),amon(rt_tas8,2)))
tasMAR <- mean(addLayer(amon(rt_tas,3),amon(rt_tas2,3),amon(rt_tas3,3),amon(rt_tas4,3),amon(rt_tas5,3),amon(rt_tas6,3),amon(rt_tas7,3),amon(rt_tas8,3)))
tasAPR <- mean(addLayer(amon(rt_tas,4),amon(rt_tas2,4),amon(rt_tas3,4),amon(rt_tas4,4),amon(rt_tas5,4),amon(rt_tas6,4),amon(rt_tas7,4),amon(rt_tas8,4)))
tasMAY <- mean(addLayer(amon(rt_tas,5),amon(rt_tas2,5),amon(rt_tas3,5),amon(rt_tas4,5),amon(rt_tas5,5),amon(rt_tas6,5),amon(rt_tas7,5),amon(rt_tas8,5)))
tasJUN <- mean(addLayer(amon(rt_tas,6),amon(rt_tas2,6),amon(rt_tas3,6),amon(rt_tas4,6),amon(rt_tas5,6),amon(rt_tas6,6),amon(rt_tas7,6),amon(rt_tas8,6)))
tasJUL <- mean(addLayer(amon(rt_tas,7),amon(rt_tas2,7),amon(rt_tas3,7),amon(rt_tas4,7),amon(rt_tas5,7),amon(rt_tas6,7),amon(rt_tas7,7),amon(rt_tas8,7)))
tasAUG <- mean(addLayer(amon(rt_tas,8),amon(rt_tas2,8),amon(rt_tas3,8),amon(rt_tas4,8),amon(rt_tas5,8),amon(rt_tas6,8),amon(rt_tas7,8),amon(rt_tas8,8)))
tasSEP <- mean(addLayer(amon(rt_tas,9),amon(rt_tas2,9),amon(rt_tas3,9),amon(rt_tas4,9),amon(rt_tas5,9),amon(rt_tas6,9),amon(rt_tas7,9),amon(rt_tas8,9)))
tasOCT <- mean(addLayer(amon(rt_tas,10),amon(rt_tas2,10),amon(rt_tas3,10),amon(rt_tas4,10),amon(rt_tas5,10),amon(rt_tas6,10),amon(rt_tas7,10),amon(rt_tas8,10)))
tasNOV <- mean(addLayer(amon(rt_tas,11),amon(rt_tas2,11),amon(rt_tas3,11),amon(rt_tas4,11),amon(rt_tas5,11),amon(rt_tas6,11),amon(rt_tas7,11),amon(rt_tas8,11)))
tasDEC <- mean(addLayer(amon(rt_tas,12),amon(rt_tas2,12),amon(rt_tas3,12),amon(rt_tas4,12),amon(rt_tas5,12),amon(rt_tas6,12),amon(rt_tas7,12),amon(rt_tas8,12)))
#
tasJAN.hist <- mean(addLayer(amon(rt_tas.hist,1),amon(rt_tas2.hist,1),amon(rt_tas3.hist,1),amon(rt_tas4.hist,1),amon(rt_tas5.hist,1),amon(rt_tas6.hist,1),amon(rt_tas7.hist,1),amon(rt_tas8.hist,1)))
tasFEB.hist <- mean(addLayer(amon(rt_tas.hist,2),amon(rt_tas2.hist,2),amon(rt_tas3.hist,2),amon(rt_tas4.hist,2),amon(rt_tas5.hist,2),amon(rt_tas6.hist,2),amon(rt_tas7.hist,2),amon(rt_tas8.hist,2)))
tasMAR.hist <- mean(addLayer(amon(rt_tas.hist,3),amon(rt_tas2.hist,3),amon(rt_tas3.hist,3),amon(rt_tas4.hist,3),amon(rt_tas5.hist,3),amon(rt_tas6.hist,3),amon(rt_tas7.hist,3),amon(rt_tas8.hist,3)))
tasAPR.hist <- mean(addLayer(amon(rt_tas.hist,4),amon(rt_tas2.hist,4),amon(rt_tas3.hist,4),amon(rt_tas4.hist,4),amon(rt_tas5.hist,4),amon(rt_tas6.hist,4),amon(rt_tas7.hist,4),amon(rt_tas8.hist,4)))
tasMAY.hist <- mean(addLayer(amon(rt_tas.hist,5),amon(rt_tas2.hist,5),amon(rt_tas3.hist,5),amon(rt_tas4.hist,5),amon(rt_tas5.hist,5),amon(rt_tas6.hist,5),amon(rt_tas7.hist,5),amon(rt_tas8.hist,5)))
tasJUN.hist <- mean(addLayer(amon(rt_tas.hist,6),amon(rt_tas2.hist,6),amon(rt_tas3.hist,6),amon(rt_tas4.hist,6),amon(rt_tas5.hist,6),amon(rt_tas6.hist,6),amon(rt_tas7.hist,6),amon(rt_tas8.hist,6)))
tasJUL.hist <- mean(addLayer(amon(rt_tas.hist,7),amon(rt_tas2.hist,7),amon(rt_tas3.hist,7),amon(rt_tas4.hist,7),amon(rt_tas5.hist,7),amon(rt_tas6.hist,7),amon(rt_tas7.hist,7),amon(rt_tas8.hist,7)))
tasAUG.hist <- mean(addLayer(amon(rt_tas.hist,8),amon(rt_tas2.hist,8),amon(rt_tas3.hist,8),amon(rt_tas4.hist,8),amon(rt_tas5.hist,8),amon(rt_tas6.hist,8),amon(rt_tas7.hist,8),amon(rt_tas8.hist,8)))
tasSEP.hist <- mean(addLayer(amon(rt_tas.hist,9),amon(rt_tas2.hist,9),amon(rt_tas3.hist,9),amon(rt_tas4.hist,9),amon(rt_tas5.hist,9),amon(rt_tas6.hist,9),amon(rt_tas7.hist,9),amon(rt_tas8.hist,9)))
tasOCT.hist <- mean(addLayer(amon(rt_tas.hist,10),amon(rt_tas2.hist,10),amon(rt_tas3.hist,10),amon(rt_tas4.hist,10),amon(rt_tas5.hist,10),amon(rt_tas6.hist,10),amon(rt_tas7.hist,10),amon(rt_tas8.hist,10)))
tasNOV.hist <- mean(addLayer(amon(rt_tas.hist,11),amon(rt_tas2.hist,11),amon(rt_tas3.hist,11),amon(rt_tas4.hist,11),amon(rt_tas5.hist,11),amon(rt_tas6.hist,11),amon(rt_tas7.hist,11),amon(rt_tas8.hist,11)))
tasDEC.hist <- mean(addLayer(amon(rt_tas.hist,12),amon(rt_tas2.hist,12),amon(rt_tas3.hist,12),amon(rt_tas4.hist,12),amon(rt_tas5.hist,12),amon(rt_tas6.hist,12),amon(rt_tas7.hist,12),amon(rt_tas8.hist,12)))
#
# Extraigo los datos de los rasterLayer con as.data.frame
# Esta funcion dispone los datos en columnas, xy=TRUE aÃ±ade las coordenadas
# Con CBIND le voy pegando datos adicionales para el resto de meses
#
rm(climXXI.north)
climXXI.north <- as.data.frame(tasJAN)
climXXI.north <- cbind(climXXI.north, as.data.frame(tasFEB))
climXXI.north <- cbind(climXXI.north, as.data.frame(tasMAR))
climXXI.north <- cbind(climXXI.north, as.data.frame(tasAPR))
climXXI.north <- cbind(climXXI.north, as.data.frame(tasMAY))
climXXI.north <- cbind(climXXI.north, as.data.frame(tasJUN))
climXXI.north <- cbind(climXXI.north, as.data.frame(tasJUL))
climXXI.north <- cbind(climXXI.north, as.data.frame(tasAUG))
climXXI.north <- cbind(climXXI.north, as.data.frame(tasSEP))
climXXI.north <- cbind(climXXI.north, as.data.frame(tasOCT))
climXXI.north <- cbind(climXXI.north, as.data.frame(tasNOV))
climXXI.north <- cbind(climXXI.north, as.data.frame(tasDEC))
climXXI.north <- cbind(climXXI.north, as.data.frame(prJAN))
climXXI.north <- cbind(climXXI.north, as.data.frame(prFEB))
climXXI.north <- cbind(climXXI.north, as.data.frame(prMAR))
climXXI.north <- cbind(climXXI.north, as.data.frame(prAPR))
climXXI.north <- cbind(climXXI.north, as.data.frame(prMAY))
climXXI.north <- cbind(climXXI.north, as.data.frame(prJUN))
climXXI.north <- cbind(climXXI.north, as.data.frame(prJUL))
climXXI.north <- cbind(climXXI.north, as.data.frame(prAUG))
climXXI.north <- cbind(climXXI.north, as.data.frame(prSEP))
climXXI.north <- cbind(climXXI.north, as.data.frame(prOCT))
climXXI.north <- cbind(climXXI.north, as.data.frame(prNOV))
climXXI.north <- cbind(climXXI.north, as.data.frame(prDEC))
#
rm(climXXI.north.hist)
climXXI.north.hist <- as.data.frame(tasJAN.hist)
climXXI.north.hist <- cbind(climXXI.north.hist, as.data.frame(tasFEB.hist))
climXXI.north.hist <- cbind(climXXI.north.hist, as.data.frame(tasMAR.hist))
climXXI.north.hist <- cbind(climXXI.north.hist, as.data.frame(tasAPR.hist))
climXXI.north.hist <- cbind(climXXI.north.hist, as.data.frame(tasMAY.hist))
climXXI.north.hist <- cbind(climXXI.north.hist, as.data.frame(tasJUN.hist))
climXXI.north.hist <- cbind(climXXI.north.hist, as.data.frame(tasJUL.hist))
climXXI.north.hist <- cbind(climXXI.north.hist, as.data.frame(tasAUG.hist))
climXXI.north.hist <- cbind(climXXI.north.hist, as.data.frame(tasSEP.hist))
climXXI.north.hist <- cbind(climXXI.north.hist, as.data.frame(tasOCT.hist))
climXXI.north.hist <- cbind(climXXI.north.hist, as.data.frame(tasNOV.hist))
climXXI.north.hist <- cbind(climXXI.north.hist, as.data.frame(tasDEC.hist))
climXXI.north.hist <- cbind(climXXI.north.hist, as.data.frame(prJAN.hist))
climXXI.north.hist <- cbind(climXXI.north.hist, as.data.frame(prFEB.hist))
climXXI.north.hist <- cbind(climXXI.north.hist, as.data.frame(prMAR.hist))
climXXI.north.hist <- cbind(climXXI.north.hist, as.data.frame(prAPR.hist))
climXXI.north.hist <- cbind(climXXI.north.hist, as.data.frame(prMAY.hist))
climXXI.north.hist <- cbind(climXXI.north.hist, as.data.frame(prJUN.hist))
climXXI.north.hist <- cbind(climXXI.north.hist, as.data.frame(prJUL.hist))
climXXI.north.hist <- cbind(climXXI.north.hist, as.data.frame(prAUG.hist))
climXXI.north.hist <- cbind(climXXI.north.hist, as.data.frame(prSEP.hist))
climXXI.north.hist <- cbind(climXXI.north.hist, as.data.frame(prOCT.hist))
climXXI.north.hist <- cbind(climXXI.north.hist, as.data.frame(prNOV.hist))
climXXI.north.hist <- cbind(climXXI.north.hist, as.data.frame(prDEC.hist))
#
# Los primeros 9216 datos son del hemisferio norte
# a partir del dato 9217 son del hemisferio sur y no valen
# porque hay que cambiar invierno por verano. Repito para el sur
# en otro orden y luego corto y pego
#
rm(climXXI.south)
climXXI.south <- as.data.frame(tasJUL)
climXXI.south <- cbind(climXXI.south, as.data.frame(tasAUG))
climXXI.south <- cbind(climXXI.south, as.data.frame(tasSEP))
climXXI.south <- cbind(climXXI.south, as.data.frame(tasOCT))
climXXI.south <- cbind(climXXI.south, as.data.frame(tasNOV))
climXXI.south <- cbind(climXXI.south, as.data.frame(tasDEC))
climXXI.south <- cbind(climXXI.south, as.data.frame(tasJAN))
climXXI.south <- cbind(climXXI.south, as.data.frame(tasFEB))
climXXI.south <- cbind(climXXI.south, as.data.frame(tasMAR))
climXXI.south <- cbind(climXXI.south, as.data.frame(tasAPR))
climXXI.south <- cbind(climXXI.south, as.data.frame(tasMAY))
climXXI.south <- cbind(climXXI.south, as.data.frame(tasJUN))
climXXI.south <- cbind(climXXI.south, as.data.frame(prJUL))
climXXI.south <- cbind(climXXI.south, as.data.frame(prAUG))
climXXI.south <- cbind(climXXI.south, as.data.frame(prSEP))
climXXI.south <- cbind(climXXI.south, as.data.frame(prOCT))
climXXI.south <- cbind(climXXI.south, as.data.frame(prNOV))
climXXI.south <- cbind(climXXI.south, as.data.frame(prDEC))
climXXI.south <- cbind(climXXI.south, as.data.frame(prJAN))
climXXI.south <- cbind(climXXI.south, as.data.frame(prFEB))
climXXI.south <- cbind(climXXI.south, as.data.frame(prMAR))
climXXI.south <- cbind(climXXI.south, as.data.frame(prAPR))
climXXI.south <- cbind(climXXI.south, as.data.frame(prMAY))
climXXI.south <- cbind(climXXI.south, as.data.frame(prJUN))
#
#
rm(climXXI.south.hist)
climXXI.south.hist <- as.data.frame(tasJUL.hist)
climXXI.south.hist <- cbind(climXXI.south.hist, as.data.frame(tasAUG.hist))
climXXI.south.hist <- cbind(climXXI.south.hist, as.data.frame(tasSEP.hist))
climXXI.south.hist <- cbind(climXXI.south.hist, as.data.frame(tasOCT.hist))
climXXI.south.hist <- cbind(climXXI.south.hist, as.data.frame(tasNOV.hist))
climXXI.south.hist <- cbind(climXXI.south.hist, as.data.frame(tasDEC.hist))
climXXI.south.hist <- cbind(climXXI.south.hist, as.data.frame(tasJAN.hist))
climXXI.south.hist <- cbind(climXXI.south.hist, as.data.frame(tasFEB.hist))
climXXI.south.hist <- cbind(climXXI.south.hist, as.data.frame(tasMAR.hist))
climXXI.south.hist <- cbind(climXXI.south.hist, as.data.frame(tasAPR.hist))
climXXI.south.hist <- cbind(climXXI.south.hist, as.data.frame(tasMAY.hist))
climXXI.south.hist <- cbind(climXXI.south.hist, as.data.frame(tasJUN.hist))
climXXI.south.hist <- cbind(climXXI.south.hist, as.data.frame(prJUL.hist))
climXXI.south.hist <- cbind(climXXI.south.hist, as.data.frame(prAUG.hist))
climXXI.south.hist <- cbind(climXXI.south.hist, as.data.frame(prSEP.hist))
climXXI.south.hist <- cbind(climXXI.south.hist, as.data.frame(prOCT.hist))
climXXI.south.hist <- cbind(climXXI.south.hist, as.data.frame(prNOV.hist))
climXXI.south.hist <- cbind(climXXI.south.hist, as.data.frame(prDEC.hist))
climXXI.south.hist <- cbind(climXXI.south.hist, as.data.frame(prJAN.hist))
climXXI.south.hist <- cbind(climXXI.south.hist, as.data.frame(prFEB.hist))
climXXI.south.hist <- cbind(climXXI.south.hist, as.data.frame(prMAR.hist))
climXXI.south.hist <- cbind(climXXI.south.hist, as.data.frame(prAPR.hist))
climXXI.south.hist <- cbind(climXXI.south.hist, as.data.frame(prMAY.hist))
climXXI.south.hist <- cbind(climXXI.south.hist, as.data.frame(prJUN.hist))
#
#climXX <- rbind(climXXI.north.hist[1:9216,],climXXI.south.hist[9217:18432,])
climXX <- rbind(climXXI.north.hist[1:(length(climXXI.north.hist[,1])/2),],
                climXXI.south.hist[(((length(climXXI.south.hist[,1])/2))+1):
                                     (length(climXXI.south.hist[,1])),])
colnames(climXX) <- c("tasJAN","tasFEB","tasMAR","tasAPR","tasMAY",
                      "tasJUN","tasJUL","tasAUG", "tasSEP", "tasOCT", 
                      "tasNOV", "tasDEC",
                      "prJAN","prFEB","prMAR","prAPR","prMAY",
                      "prJUN","prJUL","prAUG", "prSEP", "prOCT",
                      "prNOV", "prDEC")
#climXXI <- rbind(climXXI.north[1:9216,],climXXI.south[9217:18432,])
climXXI <- rbind(climXXI.north[1:(length(climXXI.north[,1])/2),],
                 climXXI.south[(((length(climXXI.south[,1])/2))+1):
                                 (length(climXXI.south[,1])),])
colnames(climXXI) <- c("tasJAN","tasFEB","tasMAR","tasAPR","tasMAY",
                       "tasJUN","tasJUL","tasAUG", "tasSEP", "tasOCT", 
                       "tasNOV", "tasDEC",
                       "prJAN","prFEB","prMAR","prAPR","prMAY",
                       "prJUN","prJUL","prAUG", "prSEP", "prOCT",
                       "prNOV", "prDEC")
#
sftlf <- as.data.frame(rt_sftlf)
latlon <- as.data.frame(raster(rt_tas,1), xy=TRUE)[,1:2]
#
latlon.land <- latlon[sftlf != 0,]
climXXI.land <- climXXI[sftlf != 0,]
climXX.land <- climXX[sftlf != 0,]
climTOT <- rbind(climXX.land,climXXI.land)
#
save(climXX,file = "F:/Tesis/Datos IPCC AR5 rcp85/PreProcessor/climXX.Rdata")
save(climXXI,file = "F:/Tesis/Datos IPCC AR5 rcp85/PreProcessor/climXXI.Rdata")
save(climXX.land,file = "F:/Tesis/Datos IPCC AR5 rcp85/PreProcessor/climXX.land.Rdata")
save(climXXI.land,file = "F:/Tesis/Datos IPCC AR5 rcp85/PreProcessor/climXXI.land.Rdata")
save(climTOT,file = "F:/Tesis/Datos IPCC AR5 rcp85/PreProcessor/climTOT.Rdata")
save(sftlf,file = "F:/Tesis/Datos IPCC AR5 rcp85/PreProcessor/sftlf.Rdata")
save(latlon,file = "F:/Tesis/Datos IPCC AR5 rcp85/PreProcessor/latlon.Rdata")
save(latlon.land,file = "F:/Tesis/Datos IPCC AR5 rcp85/PreProcessor/latlon.land.Rdata")
#