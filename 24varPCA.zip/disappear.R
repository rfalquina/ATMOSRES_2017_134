disappear <- function(climTOT.pca.reduced,nclust){
  #
  #library("fpc")
  rm(k)
  k <- kmeans(climTOT.pca.reduced, centers=nclust,iter.max=1000,nstart=250)
  #
  #
  # pinto histogramas con el número de puntos en cada cluster, separando los s. XX y XXI
  #
  rm(histXX)
  rm(histXXI)
  histXX <- hist(k$cluster[1:4387],breaks=c(-0.5:nclust+0.5),ylim = c(0, 5*6000.0/nclust), main="Climas s. XX",plot = FALSE)
  histXXI <- hist(k$cluster[4388:8774],breaks=c(-0.5:nclust+0.5),ylim = c(0, 5*6000.0/nclust), main="Climas s. XXI A2",plot = FALSE)
  #histXX$counts
  #histXXI$counts
  #
  rm(NosXX)
  NosXX <- vector(mode = "numeric")
  for(i in 1:length(histXX$counts)) {
    if (histXX$counts[i] == 0) {
      print('Cluster')
      print(i)
      print(' no existe en el s. XX')
      NosXX <- c(NosXX,i)
    }
  }
  #
  rm(NosXXI)
  NosXXI <- vector(mode = "numeric")
  for(i in 1:length(histXXI$counts)) {
    if (histXXI$counts[i] == 0) {
      print('Cluster')
      print(i)
      print(' no existe en el s. XXI')
      NosXXI <- c(NosXXI,i)
    }
  }
  #
  rm(color.map)
  color.map <- vector(mode="numeric", length=length(k$cluster))
  color.map <- rep(0, times=8774)
  #
  if(length(NosXXI) != 0) {
    for(j in 1:length(NosXXI)) {
      for(i in 1:4387) {
        if (k$cluster[i] == NosXXI[j]) {color.map[i] <- 1}
      }
    }
  }
  #
  if(length(NosXX) != 0) {
    for(j in 1:length(NosXX)) {
      for(i in 4388:8774) {
        if (k$cluster[i] == NosXX[j]) {color.map[i] <- 1}
      }
    }
  }
  #
  color.map }
#