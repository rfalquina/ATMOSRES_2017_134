#
#
setwd("F:/Tesis/Datos IPCC AR5 rcp85/24varPCA")
#
#
library("ncdf4")
library("raster")
#
# Lectura de datos generados en PreProcessor
# leo los datos climaticos del s. XX y del s. XXI
# combinados en climTOT
#
load(file = "F:/Tesis/Datos IPCC AR5 rcp85/PreProcessor/sftlf.Rdata")
load(file = "F:/Tesis/Datos IPCC AR5 rcp85/PreProcessor/latlon.Rdata")
load(file = "F:/Tesis/Datos IPCC AR5 rcp85/PreProcessor/climXX.Rdata")
load(file = "F:/Tesis/Datos IPCC AR5 rcp85/PreProcessor/climXXI.Rdata")
#
# Filtramos los datos para eliminar el oceano y la Antartida
#
latlon.land <- latlon[(sftlf != 0) & (latlon$y >= -60.),]
climXXI.land <- climXXI[(sftlf != 0) & (latlon$y >= -60.),]
climXX.land <- climXX[(sftlf != 0) & (latlon$y >= -60.),]
climTOT <- rbind(climXX.land,climXXI.land)
#
#
climTOT.pca <- prcomp(climTOT,center = TRUE, scale. = TRUE)
summary(climTOT.pca)
climTOT.pca.reduced <- data.frame(climTOT.pca$x[,1:4])
#
#
rm(color.map)
nclust<-120
Sys.time()
color.map <- disappear(climTOT.pca.reduced,nclust)
#
for(k in 1:100) {
  color.map <- color.map+disappear(climTOT.pca.reduced,nclust)
}
Sys.time()
#
save(color.map, file = "F:/Tesis/Datos IPCC AR5 rcp85/24varPCA/color-map-120clusters.Rdata")
#
load(file = "F:/Tesis/Datos IPCC AR5 rcp85/24varPCA/color-map-120Clusters.Rdata")
load(file = "F:/Tesis/Datos IPCC AR5 rcp85/24varPCA/color-map-60Clusters.Rdata")
color.map <- color.map+1
#
# genero una paleta con 101 colores
#
library(RColorBrewer)
library(scales)
library(OceanView)
library(plot3D)
#
c101 <- c(1:102)
#c101[102:1] <- c(ramp.col(c("black", "grey"), n = 101), "white")      
c101[90:1] <- c("white")    
c101[102:90] <- c("black")    
#
palette(c101)
#
#
plot(latlon.land,col=color.map[1:4387],pch=18, xlab="", ylab="")
title(main="RCP 8.5 s. XX disappearing climates (k-means 120 clusters)", xlab="Longitude", ylab="Latitude")
title(xlab="Longitude", ylab="Latitude")
plot(latlon.land,col=color.map[4388:8774],pch=18, xlab="", ylab="")
title(main="RCP 8.5 s. XXI novel climates (k-means 60 clusters)", xlab="Longitude", ylab="Latitude")
title(xlab="Longitude", ylab="Latitude")
#
#
# AÃ±adimos el perfil de la tierra emergida por estetica
#
library("GEOmap")
require("geomapdata")
data(coastmap)
plotGEOmap(coastmap, border=black, add=TRUE, MAPstyle=2, MAPcol="grey")
#
#
# Calculemos el area (km ^2) de las zonas afectadas por la aparicion
# o desaparicion de sus climas
#
rt_sftlf <- raster("F:/Tesis/Datos IPCC AR5 rcp85/sftlf_fx_MPI-ESM-MR_rcp85_r0i0p0.nc", varname="sftlf", lvar=)
cellArea <- as.data.frame(area(rt_sftlf))
load(file = "F:/Tesis/Datos IPCC AR5 rcp85/PreProcessor/sftlf.Rdata")
cellArea.land <- cellArea[(sftlf != 0) & (latlon$y >= -60.),]
sXX.land <- (color.map[1:4387] > 90.)
sXXI.land <- (color.map[4388:8774] > 90.)
sum(cellArea.land[sXX.land])
sum(cellArea.land[sXXI.land])
#