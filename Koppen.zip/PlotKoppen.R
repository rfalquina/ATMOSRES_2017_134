#
#
setwd("F:/Tesis/Datos IPCC AR5 rcp85/Koppen")
#
# leo los datos climaticos del s. XX y del s. XXI
# utilizo los resultados del modelo MPI-ESM-MR del Instituto Max Planck
# en formato netCDF
#
library("ncdf4")
library("raster")
#
# Lectura de datos generados en PreProcessor
#
load(file = "F:/Tesis/Datos IPCC AR5 rcp85/PreProcessor/climXX.Rdata")
load(file = "F:/Tesis/Datos IPCC AR5 rcp85/PreProcessor/latlon.Rdata")
load(file = "F:/Tesis/Datos IPCC AR5 rcp85/PreProcessor/sftlf.Rdata")
#
# Filtramos los datos para eliminar el oceano y la Antartida
#
latlon.land <- latlon[(sftlf != 0) & (latlon$y >= -60.),]
climXX.land <- climXX[(sftlf != 0) & (latlon$y >= -60.),]
climTOT <- climXX.land
#
climTOT.pca <- prcomp(climTOT,center = TRUE, scale. = TRUE)
summary(climTOT.pca)
climTOT.pca$rotation
climTOT.pca.reduced <- data.frame(climTOT.pca$x[,1:4])
#
#
#
# Dibujo dos paneles en paralelo
par(mfrow=c(1,2),oma = c(2, 2, 2, 2))
#
#
# Clasificar los climas del s.XX con el algoritmo k-means
#
#
rm(color.map,nclust,k,centroid,T_order,c31)
nclust<-31
load(file = "F:/Tesis/Datos IPCC AR5 rcp85/Koppen/kmeans.Rdata")
#
# Para el subconjunto de puntos en cada cluster, promediamos los valores de las
# 24 variables para obtener un valor representativo del cluster
#
centroid <- sapply(climTOT[k$cluster==1,],mean)
for (i in 2:nclust) {centroid <- rbind(centroid,sapply(climTOT[k$cluster==i,],mean))}
#
# ordenamos los centroides por temperatura media anual, en orden decreciente
#
T_order <- order(apply(centroid[,1:12],1,mean),decreasing=TRUE)
#
# Pintamos el mapa resultante con un codigo de colores para representar
# el numero de cluster en cada celda
#
# genero una paleta con 31 colores
#
library(RColorBrewer)
library(scales)
library(OceanView)
library(plot3D)
#
c31 <- c(1:31)
c31[T_order] <- c(ramp.col(c("red", "darkred"), n = 4),           #A..
                  ramp.col(c("yellow", "orange"), n = 4),         #B..
                  ramp.col(c("lightgreen","darkgreen"), n = 9),   #C..
                  ramp.col(c("lightblue", "darkblue"), n = 11),   #D..
                  "lightgrey", "darkgrey","black")
palette(c("white",c31))
#
# Asigno el numero de cluster a "color.map" y le sumo 1 para eliminar
# los puntos blancos
#
#
# pch=46 cuadrado de 0.01 inch, cex=8 multiplicar tamaño por 8
#
color.map <- k$cluster+1
#
plot(latlon.land, col=color.map, pch=46, cex=8, xlab="Longitude", ylab="Latitude"
     , main="XX Century Climates, k-means", cex.main=1.5)
#
# Añadimos el perfil de la tierra emergida por estetica
#
library("GEOmap")
require("geomapdata")
data(coastmap)
plotGEOmap(coastmap, border=black, add=TRUE, MAPstyle=2)
#
#
#
#
#
#
#
# Clasificar los climas del s.XX con el algoritmo agnes
# "Ward Method"
#
library(cluster)
#
rm(color.map.agnes.Ward,nclust,kcluster,centroid,T_order,c31)
nclust<-31
load(file = "F:/Tesis/Datos IPCC AR5 rcp85/Koppen/kagnes.ward.Rdata")
#
#plot(kstd, which.plots = 2)
#
kcluster <- cutree(kagnes.Ward, k = nclust)
color.map.agnes.Ward <- kcluster+1
#
centroid <- sapply(climTOT[kcluster==1,],mean)
for (i in 2:nclust) {centroid <- rbind(centroid,sapply(climTOT[kcluster==i,],mean))}
#
# ordenamos los centroides por temperatura media anual, en orden decreciente
#
T_order <- order(apply(centroid[,1:12],1,mean),decreasing=TRUE)
#
# Pintamos el mapa resultante con un codigo de colores para representar
# el numero de cluster en cada celda
#
# genero una paleta con 31 colores
#
library(RColorBrewer)
library(scales)
library(OceanView)
library(plot3D)
#
rm(c31)
c31 <- c(1:31)
c31[T_order] <- c(ramp.col(c("red", "darkred"), n = 4),           #A..
                  ramp.col(c("yellow", "orange"), n = 4),         #B..
                  ramp.col(c("lightgreen","darkgreen"), n = 9),   #C..
                  ramp.col(c("lightblue", "darkblue"), n = 11),   #D..
                  "lightgrey", "darkgrey","black")
palette(c("white",c31))
plot(latlon.land, col=color.map.agnes.Ward,pch=46, cex=8, xlab="Longitude", 
     ylab="Latitude", main="XX Century Climates, Ward Method", cex.main=1.5)
#
#
library("GEOmap")
require("geomapdata")
data(coastmap)
plotGEOmap(coastmap, border=black, add=TRUE, MAPstyle=2)
#
# Titulo de la figura bajo las dos graficas
#
mtext('Fig. 1. Classifications of XX century climates using k-means and Ward clustering algorithms', 
      side= 1, outer = TRUE, cex = 1.5, family="sans")
#
#
#
#
#
#
# Clasificar los climas del s.XX con el algoritmo agnes
#
library(cluster)
#
rm(color.map.agnes,nclust,kcluster,centroid,T_order,c31)
load(file = "F:/Tesis/Datos IPCC AR5 rcp85/Koppen/kagnes.Rdata")
#
#
nclust<-31
#
kcluster <- cutree(kagnes, k = nclust)
#
centroid <- sapply(climTOT[kcluster==1,],mean)
for (i in 2:nclust) {centroid <- rbind(centroid,sapply(climTOT[kcluster==i,],mean))}
#
# ordenamos los centroides por temperatura media anual, en orden decreciente
#
T_order <- order(apply(centroid[,1:12],1,mean),decreasing=TRUE)
#
# Pintamos el mapa resultante con un codigo de colores para representar
# el numero de cluster en cada celda
#
# genero una paleta con 31 colores
#
library(RColorBrewer)
library(scales)
library(OceanView)
library(plot3D)
#
rm(c31)
c31 <- c(1:31)
c31[T_order] <- c(ramp.col(c("red", "darkred"), n = 4),           #A..
                  ramp.col(c("yellow", "orange"), n = 4),         #B..
                  ramp.col(c("lightgreen","darkgreen"), n = 9),   #C..
                  ramp.col(c("lightblue", "darkblue"), n = 11),   #D..
                  "lightgrey", "darkgrey","black")
palette(c("white",c31))
#
color.map.agnes <- kcluster+1
plot(latlon.land, col=color.map.agnes,pch=46, cex=8, xlab="Longitude", 
     ylab="Latitude", main="XX Century Climates, AGNES average linkage")
#
#
library("GEOmap")
require("geomapdata")
data(coastmap)
plotGEOmap(coastmap, border=black, add=TRUE, MAPstyle=2)
#
#
#
#
#
#