#
#
setwd("F:/Tesis/Datos IPCC AR5 rcp85/Koppen")
#
# leo los datos climaticos del s. XX y del s. XXI
# utilizo los resultados del modelo MPI-ESM-MR del Instituto Max Planck
# en formato netCDF
#
library("ncdf4")
library("raster")
#
# Lectura de datos generados en PreProcessor
#
load(file = "F:/Tesis/Datos IPCC AR5 rcp85/PreProcessor/climXX.Rdata")
load(file = "F:/Tesis/Datos IPCC AR5 rcp85/PreProcessor/latlon.Rdata")
load(file = "F:/Tesis/Datos IPCC AR5 rcp85/PreProcessor/sftlf.Rdata")
#
# Filtramos los datos para eliminar el oceano y la Antartida
#
latlon.land <- latlon[(sftlf != 0) & (latlon$y >= -60.),]
climXX.land <- climXX[(sftlf != 0) & (latlon$y >= -60.),]
climTOT <- climXX.land
#
climTOT.pca <- prcomp(climTOT,center = TRUE, scale. = TRUE)
summary(climTOT.pca)
climTOT.pca$rotation
climTOT.pca.reduced <- data.frame(climTOT.pca$x[,1:4])
#
#
#
#
#
# Clasificar los climas del s.XX con el algoritmo k-means
#
#
rm(color.map,nclust,k,centroid,T_order,c31)
nclust<-31
k <- kmeans(climTOT.pca.reduced, centers=nclust,iter.max=1000,nstart=500)
save(k, file = "F:/Tesis/Datos IPCC AR5 rcp85/Koppen/kmeans.Rdata")
#
# Para el subconjunto de puntos en cada cluster, promediamos los valores de las
# 24 variables para obtener un valor representativo del cluster
#
centroid <- sapply(climTOT[k$cluster==1,],mean)
for (i in 2:nclust) {centroid <- rbind(centroid,sapply(climTOT[k$cluster==i,],mean))}
#
# ordenamos los centroides por temperatura media anual, en orden decreciente
#
T_order <- order(apply(centroid[,1:12],1,mean),decreasing=TRUE)
#
# Pintamos el mapa resultante con un codigo de colores para representar
# el numero de cluster en cada celda
#
# genero una paleta con 31 colores
#
library(RColorBrewer)
library(scales)
library(OceanView)
library(plot3D)
#
c31 <- c(1:31)
c31[T_order] <- c(ramp.col(c("red", "darkred"), n = 4),           #A..
         ramp.col(c("yellow", "orange"), n = 4),         #B..
         ramp.col(c("lightgreen","darkgreen"), n = 9),   #C..
         ramp.col(c("lightblue", "darkblue"), n = 11),   #D..
         "lightgrey", "darkgrey","black")
palette(c("white",c31))
#
# Asigno el numero de cluster a "color.map" y le sumo 1 para eliminar
# los puntos blancos
#
#
# pch=46 cuadrado de 0.01 inch, cex=8 multiplicar tamaño por 8
#
color.map <- k$cluster+1
#
plot(latlon.land, col=color.map, pch=46, cex=8, xlab="Longitude", ylab="Latitude"
     , main="XX Century Climates, k-means")
#
# Añadimos el perfil de la tierra emergida por estetica
#
library("GEOmap")
require("geomapdata")
data(coastmap)
plotGEOmap(coastmap, border=black, add=TRUE, MAPstyle=2)
#
#
#
#
#
#
#
#
# Clasificar los climas del s.XX con el algoritmo agnes
#
library(cluster)
#
rm(color.map.agnes,nclust,kcluster,centroid,T_order,c31)
kagnes <- agnes(climTOT.pca.reduced, diss=FALSE, 
                metric = "euclidean", keep.diss = FALSE, keep.data = FALSE)
save(kagnes, file = "F:/Tesis/Datos IPCC AR5 rcp85/Koppen/kagnes.Rdata")
#
#
nclust<-31
#
kcluster <- cutree(kagnes, k = nclust)
#
centroid <- sapply(climTOT[kcluster==1,],mean)
for (i in 2:nclust) {centroid <- rbind(centroid,sapply(climTOT[kcluster==i,],mean))}
#
# ordenamos los centroides por temperatura media anual, en orden decreciente
#
T_order <- order(apply(centroid[,1:12],1,mean),decreasing=TRUE)
#
# Pintamos el mapa resultante con un codigo de colores para representar
# el numero de cluster en cada celda
#
# genero una paleta con 31 colores
#
library(RColorBrewer)
library(scales)
library(OceanView)
library(plot3D)
#
rm(c31)
c31 <- c(1:31)
c31[T_order] <- c(ramp.col(c("red", "darkred"), n = 4),           #A..
                  ramp.col(c("yellow", "orange"), n = 4),         #B..
                  ramp.col(c("lightgreen","darkgreen"), n = 9),   #C..
                  ramp.col(c("lightblue", "darkblue"), n = 11),   #D..
                  "lightgrey", "darkgrey","black")
palette(c("white",c31))
#
color.map.agnes <- kcluster+1
plot(latlon.land, col=color.map.agnes,pch=46, cex=8, xlab="Longitude", 
     ylab="Latitude", main="XX Century Climates, AGNES average linkage")
#
#
library("GEOmap")
require("geomapdata")
data(coastmap)
plotGEOmap(coastmap, border=black, add=TRUE, MAPstyle=2)
#
#
#
#
#
#
# Clasificar los climas del s.XX con el algoritmo agnes
# "Ward Method"
#
library(cluster)
#
rm(color.map.agnes.Ward,nclust,kcluster,centroid,T_order,c31)
nclust<-31
kagnes.Ward <- agnes(climTOT.pca.reduced, diss=FALSE, 
                              metric = "euclidean", keep.diss = FALSE, keep.data = FALSE,
                              method = "ward")
save(kagnes.Ward, file = "F:/Tesis/Datos IPCC AR5 rcp85/Koppen/kagnes.ward.Rdata")
#
#plot(kstd, which.plots = 2)
#
kcluster <- cutree(kagnes.Ward, k = nclust)
color.map.agnes.Ward <- kcluster+1
#
centroid <- sapply(climTOT[kcluster==1,],mean)
for (i in 2:nclust) {centroid <- rbind(centroid,sapply(climTOT[kcluster==i,],mean))}
#
# ordenamos los centroides por temperatura media anual, en orden decreciente
#
T_order <- order(apply(centroid[,1:12],1,mean),decreasing=TRUE)
#
# Pintamos el mapa resultante con un codigo de colores para representar
# el numero de cluster en cada celda
#
# genero una paleta con 31 colores
#
library(RColorBrewer)
library(scales)
library(OceanView)
library(plot3D)
#
rm(c31)
c31 <- c(1:31)
c31[T_order] <- c(ramp.col(c("red", "darkred"), n = 4),           #A..
                  ramp.col(c("yellow", "orange"), n = 4),         #B..
                  ramp.col(c("lightgreen","darkgreen"), n = 9),   #C..
                  ramp.col(c("lightblue", "darkblue"), n = 11),   #D..
                  "lightgrey", "darkgrey","black")
palette(c("white",c31))
plot(latlon.land, col=color.map.agnes.Ward,pch=46, cex=8, xlab="Longitude", 
     ylab="Latitude", main="XX Century Climates, AGNES Ward Method")
#
#
library("GEOmap")
require("geomapdata")
data(coastmap)
plotGEOmap(coastmap, border=black, add=TRUE, MAPstyle=2)
#
#
#
#
#
#
#
#
#
#
#
# Clasificar los climas del s.XX con el algoritmo PAM
# (Partition Around Medoids)
#
# In contrast to the k-means algorithm, 
# k-medoids chooses datapoints as centers (medoids or exemplars) 
#
library(cluster)
#
rm(color.map.pam)
kpam <- pam(climTOT.pca.reduced, k=nclust, metric = "euclidean", diss = FALSE,
                stand = FALSE, keep.data = FALSE, keep.diss = FALSE)
#
#plot(kstd, which.plots = 2)
#
color.map.pam <- kpam$clustering+1
save(color.map.pam, file = "F:/Tesis/Datos IPCC AR5 rcp85/Koppen/color-map-pam.Rdata")
#
#
plot(latlon.land, col=color.map.pam, pch=18, xlab="Longitude", 
     ylab="Latitude", main="XX Century Climates, PAM")
#
plotGEOmap(coastmap, border=black, add=TRUE, MAPstyle=2)
#
rm(mapaXX.pam)
mapaXX.pam <- latlon
mapaXX.pam <- cbind(mapaXX.pam,0)
mapaXX.pam[(sftlf != 0) & (latlon$y >= -60.),3] <- color.map.pam[1:(length(latlon.land$x))]
coordinates(mapaXX.pam) <- ~ x + y
gridded(mapaXX.pam) <- TRUE
raster.mapaXX.pam <- raster(mapaXX.pam)
#
#
#
#
#
#
#
#
#
#
# Clasificar los climas del s.XX con el algoritmo PAM
# (Partition Around Medoids) y metrica Manhattan
#
# In contrast to the k-means algorithm, 
# k-medoids chooses datapoints as centers (medoids or exemplars) 
#
library(cluster)
#
rm(color.map.pam.manhattan)
kpam.manhattan <- pam(climTOT.pca.reduced, k=nclust, metric = "manhattan", diss = FALSE,
            stand = FALSE, keep.data = FALSE, keep.diss = FALSE)
#
#
color.map.pam.manhattan <- kpam.manhattan$clustering+1
save(color.map.pam.manhattan, file = "F:/Tesis/Datos IPCC AR5 rcp85/Koppen/color-map-pamManhattan.Rdata")
#
#
plot(latlon.land, col=color.map.pam.manhattan, pch=18, xlab="Longitude", 
     ylab="Latitude", main="XX Century Climates, PAM Manhattan")
#
plotGEOmap(coastmap, border=black, add=TRUE, MAPstyle=2)
#
rm(mapaXX.pam.manhattan)
mapaXX.pam.manhattan <- latlon
mapaXX.pam.manhattan <- cbind(mapaXX.pam.manhattan,0)
mapaXX.pam.manhattan[(sftlf != 0) & (latlon$y >= -60.),3] <- color.map.pam.manhattan[1:(length(latlon.land$x))]
coordinates(mapaXX.pam.manhattan) <- ~ x + y
gridded(mapaXX.pam.manhattan) <- TRUE
raster.mapaXX.pam.manhattan <- raster(mapaXX.pam.manhattan)
#
#
#
#
#
#
#
#
#
# Clasificar los climas del s.XX con el algoritmo CLARA
#
# (Clustering for Large Applications) algorithm for tackling 
# large applications. CLARA extends their k-medoids approach 
# for a large number of objects. It works by clustering a sample 
# from the dataset and then assigns all objects in the dataset 
# to these clusters
#
library(cluster)
#
rm(color.map.clara)
kclara <- clara(climTOT.pca.reduced, k=nclust, metric = "euclidean", 
                samples= 250, stand = FALSE, keep.data = FALSE)
#
#plot(kstd, which.plots = 2)
#
color.map.clara <- kclara$clustering+1
save(color.map.clara, file = "F:/Tesis/Datos IPCC AR5 rcp85/Koppen/color-map-clara.Rdata")
#
plot(latlon.land, col=color.map.clara, pch=18, xlab="Longitude", 
     ylab="Latitude", main="XX Century Climates, CLARA")
plotGEOmap(coastmap, border=black, add=TRUE, MAPstyle=2)
#
rm(mapaXX.clara)
mapaXX.clara <- latlon
mapaXX.clara <- cbind(mapaXX.clara,0)
mapaXX.clara[(sftlf != 0) & (latlon$y >= -60.),3] <- color.map.clara[1:(length(latlon.land$x))]
coordinates(mapaXX.clara) <- ~ x + y
gridded(mapaXX.clara) <- TRUE
raster.mapaXX.clara <- raster(mapaXX.clara)
#
#
#
# Defining palettes
#
# Cada paleta debe tener al menos nclust colores diferentes, si no los recicla
#
#
#
# la libreria RColorBrewer genera paletas de colores distinguibles
#
library(RColorBrewer)
library(scales)
library(OceanView)
library(plot3D)
palette(alpha(brewer.pal(9,'Reds'), 0.5))
palette(alpha(brewer.pal(9,'RdPu'), 0.5))
palette(alpha(brewer.pal(9,'Oranges'), 0.5))
palette(alpha(brewer.pal(9,'YlOrRd'), 0.5))
display.brewer.all()
#
#
# genero una paleta con 30 colores
#
c30 <- c(ramp.col(c("red", "darkred"), n = 4),           #A..
         ramp.col(c("yellow", "orange"), n = 4),         #B..
         ramp.col(c("lightgreen","darkgreen"), n = 9),   #C..
         ramp.col(c("lightblue", "darkblue"), n = 11),   #D..
         "lightgrey", "darkgrey")
palette(c("white",c30))
palette(c("white",rainbow(40)))
palette(c("white",topo.colors(40)))
palette(c("white",terrain.colors(40)))
palette(c("white",heat.colors(40)))
palette(c("white",cm.colors(50)))
#
#
#
#
#
# Plotting maps
#
#
plot(raster.mapaXX, main="XX Century Climates, k-means", xlab="Lon", ylab="Lat", col=palette())
plot(raster.mapaXX.agnes, main="XX Century Climates, AGNES", xlab="Lon", ylab="Lat",pch=16, col=palette())
plot(raster.mapaXX.clara, main="XX Century Climates, CLARA", xlab="Lon", ylab="Lat",pch=16, col=palette())
plot(raster.mapaXX.pam, main="XX Century Climates, PAM", xlab="Lon", ylab="Lat",pch=16, col=palette())
#
#