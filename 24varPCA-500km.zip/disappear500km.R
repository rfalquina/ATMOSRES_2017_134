disappear500km <- function(latlon.land, climTOT.pca.reduced,nclust){
#
#
  rm(k)
  k <- kmeans(climTOT.pca.reduced, centers=nclust,iter.max=1000,nstart=250)
#
  rm(color.map)
  num.points <- length(latlon.land$x)
  color.map <- vector(mode="numeric", length=2*num.points)
  color.map <- rep(1, times=2*num.points)
#
  ksXX.cluster <- k$cluster[1:num.points]
  ksXXI.cluster <- k$cluster[(num.points+1):(2*num.points)]
#
  for(i in 1:num.points) {
    if(sum(ksXXI.cluster==k$cluster[i]) == 0) {next} else {
      if(min(pointDistance(latlon.land[i,],latlon.land[ksXXI.cluster==k$cluster[i],],
                           lonlat=TRUE)) > 500000.) {next()} else 
                           {color.map[i] <- 0}
    }
  }
#
  for(i in (num.points+1):(2*num.points)) {
    if(sum(ksXX.cluster==k$cluster[i]) == 0) {next} else {
      if(min(pointDistance(latlon.land[i-num.points,],latlon.land[ksXX.cluster==k$cluster[i],],
                           lonlat=TRUE)) > 500000.) {next()} else 
                           {color.map[i] <- 0}
    }
  }
# browser()
  #  
color.map }
#