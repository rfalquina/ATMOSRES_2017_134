#
#
setwd("F:/Tesis/Datos IPCC AR5 rcp85/24varPCA-Ward")
#
#
library("ncdf4")
library("raster")
library(cluster)
#
# Lectura de datos generados en PreProcessor
# leo los datos climaticos del s. XX y del s. XXI
# combinados en climTOT
#
load(file = "F:/Tesis/Datos IPCC AR5 rcp85/PreProcessor/sftlf.Rdata")
load(file = "F:/Tesis/Datos IPCC AR5 rcp85/PreProcessor/latlon.Rdata")
load(file = "F:/Tesis/Datos IPCC AR5 rcp85/PreProcessor/climXX.Rdata")
load(file = "F:/Tesis/Datos IPCC AR5 rcp85/PreProcessor/climXXI.Rdata")
#
# Filtramos los datos para eliminar el oceano y la Antartida
#
latlon.land <- latlon[(sftlf != 0) & (latlon$y >= -60.),]
climXXI.land <- climXXI[(sftlf != 0) & (latlon$y >= -60.),]
climXX.land <- climXX[(sftlf != 0) & (latlon$y >= -60.),]
climTOT <- rbind(climXX.land,climXXI.land)
#
#
climTOT.pca <- prcomp(climTOT,center = TRUE, scale. = TRUE)
summary(climTOT.pca)
climTOT.pca.reduced <- data.frame(climTOT.pca$x[,1:4])
#
#
rm(kagnes)
Sys.time()
kagnes <- agnes(climTOT.pca.reduced, diss=FALSE, 
                metric = "euclidean", keep.diss = FALSE, keep.data = FALSE,
                method = "ward")
Sys.time()
save(kagnes,file = "F:/Tesis/Datos IPCC AR5 rcp85/24varPCA-Ward/kagnes.Rdata")
rm(kagnes)
load(file = "F:/Tesis/Datos IPCC AR5 rcp85/24varPCA-Ward/kagnes.Rdata")
nclust<-44
rm(color.map)
color.map <- disappear(kagnes,nclust)
#
color.map <- color.map+1
#
# genero una paleta con 101 colores
#
library(RColorBrewer)
library(scales)
library(OceanView)
library(plot3D)
#
c101 <- c(1:2)
c101[1:2] <- c("white","black")    
palette(c101)
#
#
plot(latlon.land,col=color.map[1:4387],pch=18, xlab="", ylab="")
title(main="RCP 8.5 s. XX disappearing climates (Ward's 44 clusters)", xlab="Longitude", ylab="Latitude")
title( xlab="Longitude", ylab="Latitude")
plot(latlon.land,col=color.map[4388:8774],pch=18, xlab="", ylab="")
title(main="RCP 8.5 s. XXI novel climates (Ward's 44 clusters)", xlab="Longitude", ylab="Latitude")
title( xlab="Longitude", ylab="Latitude")
#
#
# Añadimos el perfil de la tierra emergida por estetica
#
library("GEOmap")
require("geomapdata")
data(coastmap)
plotGEOmap(coastmap, border=black, add=TRUE, MAPstyle=2, MAPcol="grey")
#
data("asia.bdy")
plotGEOmap(asia.bdy, border=black, add=TRUE, MAPstyle=2, MAPcol="grey")
data("africa.bdy")
plotGEOmap(africa.bdy, border=black, add=TRUE, MAPstyle=2, MAPcol="grey")
data("USAmap")
plotGEOmap(USAmap, border=black, add=TRUE, MAPstyle=2, MAPcol="grey")
#
#
#
# Calculemos el area (km ^2) de las zonas afectadas por la aparicion
# o desaparicion de sus climas
#
rt_sftlf <- raster("F:/Tesis/Datos IPCC AR5 rcp85/sftlf_fx_MPI-ESM-MR_rcp85_r0i0p0.nc", varname="sftlf", lvar=)
cellArea <- as.data.frame(area(rt_sftlf))
load(file = "F:/Tesis/Datos IPCC AR5 rcp85/PreProcessor/sftlf.Rdata")
cellArea.land <- cellArea[(sftlf != 0) & (latlon$y >= -60.),]
sXX.land <- (color.map[1:4387] > 1.)
sXXI.land <- (color.map[4388:8774] > 1.)
sum(cellArea.land[sXX.land])
sum(cellArea.land[sXXI.land])
#
#
#
#
#
#
#
#
#
#
# Climograma de los clusters disappXX (aparecen en el XXI, no estaban en el XX)
#
kcluster <- cutree(kagnes, k = nclust)
MonthName <- c("JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG", "SEP", "OCT","NOV", "DEC")
disappXX <- 44
vec <- kcluster[4388:8774]==disappXX
rm(centroid, centroidXX, centroidXXI)
centroid <- sapply(climTOT[kcluster==disappXX,],mean)
centroidXX <- sapply(climXX.land[vec,],mean)
centroidXXI <- sapply(climXXI.land[vec,],mean)
#
palette("default")
par(mar=c(5,4,4,4))
barplot(centroidXXI[1:12],ylim=c(220,320), xpd=FALSE, xlab="Month", ylab="Average Temp. (K)", 
        names.arg=MonthName)
par(new=T)
plot(centroidXXI[13:24], axes=F,xlab="",ylab="", type="b",col=4,ylim=c(5E-07,5E-06))
axis(side=4, col=4,col.axis = 4)
mtext("Precipitation flux (kg m-2 s-1)",side=4,line=2,col=4)
title(main = "21st century climograph for area shown in Fig. 3")
#title(main = "Saharian novel climate climograph (21st century)")
par(new=F)
#
par(mar=c(5,4,4,4))
barplot(centroidXX[1:12],ylim=c(220,320), xpd=FALSE, xlab="Month", ylab="Average Temp. (K)", 
        names.arg=MonthName)
par(new=T)
plot(centroidXX[13:24], axes=F,xlab="",ylab="", type="b",col=4,ylim=c(5E-07,5E-06))
axis(side=4, col=4,col.axis = 4)
mtext("Precipitation flux (kg m-2 s-1)",side=4,line=2,col=4)
title(main = "20th century climograph for area shown in Fig. 3")
#title(main = "Saharian novel climate climograph (20th century)")
par(new=F)
#
mean(centroidXX[1:12])
mean(centroidXXI[1:12])
mean(centroidXX[13:24])
mean(centroidXXI[13:24])
#
#
#
#
# Climograma de los clusters appXXI (desaparecen del XX, donde existian, y no estan en XXI)
#
appXXI <- 3
rm(centroid, centroidXX, centroidXXI,vec)
vec <- kcluster[1:4387]==appXXI
centroidXX <- sapply(climXX.land[vec,],mean)
centroidXXI <- sapply(climXXI.land[vec,],mean)
#
palette("default")
par(mar=c(5,4,4,4))
barplot(centroidXXI[1:12],ylim=c(220,320), xpd=FALSE, xlab="Month", ylab="Average Temp. (K)", 
        names.arg=MonthName)
par(new=T)
plot(centroidXXI[13:24], axes=F,xlab="",ylab="", type="b",col=4,ylim=c(5E-06,3E-05))
axis(side=4, col=4,col.axis = 4)
mtext("Precipitation flux (kg m-2 s-1)",side=4,line=2,col=4)
title(main = "21st century climograph for area shown in Fig. 2")
#title(main = "Siberian disappearing climate climograph (21th century)")
par(new=F)
#
par(mar=c(5,4,4,4))
barplot(centroidXX[1:12],ylim=c(220,320), xpd=FALSE, xlab="Month", ylab="Average Temp. (K)", 
        names.arg=MonthName)
par(new=T)
plot(centroidXX[13:24], axes=F,xlab="",ylab="", type="b",col=4,ylim=c(5E-06,3E-05))
axis(side=4, col=4,col.axis = 4)
mtext("Precipitation flux (kg m-2 s-1)",side=4,line=2,col=4)
title(main = "20th century climograph for area shown in Fig. 2")
#title(main = "Siberian disappearing climate climograph (20th century)")
par(new=F)
#
mean(centroidXX[1:12])
mean(centroidXXI[1:12])
mean(centroidXX[13:24])
mean(centroidXXI[13:24])
#
#
#
# Analisis de centroides de cada cluster en cada siglo
#
kcluster <- cutree(kagnes, k = nclust)
kclusterXX <- kcluster[1:4387]
kclusterXXI <- kcluster[4388:8774]
#
centroXX <- c(1:100)
centroXXI <- c(1:100)
dim(centroXX) <- c(50,2)
dim(centroXXI) <- c(50,2)
for(i in 1:44) {
  centroXX[i,1] <- mean(sapply(climXX.land[kclusterXX==i,], mean)[1:12])
  centroXX[i,2] <- mean(sapply(climXX.land[kclusterXX==i,], mean)[13:24])
  centroXXI[i,1] <- mean(sapply(climXXI.land[kclusterXXI==i,], mean)[1:12])
  centroXXI[i,2] <- mean(sapply(climXXI.land[kclusterXXI==i,], mean)[13:24])
}
plot(centroXX,pch=0,ylim=c(5E-08,1.6E-04),xlim=c(250,315),
     xlab="Average Temp. (K)", ylab="Precipitation flux (kg m-2 s-1)")
text(centroXX, c(as.character(1:nclust)), cex=0.4, pos=4, col="black")
par(new=T)
plot(centroXXI, col="red",pch=2, ylim=c(5E-08,1.6E-04),xlim=c(250,315),
     xlab="",ylab="")
text(centroXXI, c(as.character(1:nclust)), cex=0.4, pos=4, col="red")
#
par(new=T)
plot(centroXX[3,1],centroXX[3,2],col="blue", pch=15,
     ylim=c(5E-08,1.6E-04),xlim=c(250,315), xlab="",ylab="")
par(new=T)
plot(centroXXI[44,1],centroXXI[44,2],col="purple", pch=17,
     ylim=c(5E-08,1.6E-04),xlim=c(250,315), xlab="",ylab="")
title(main = "Average precipitation vs. average temperature for each cluster in each century",
      cex.main=0.7)
#
#
#
#
# Analisis de centroides de cada cluster conjuntamente para ambos siglos
#
#
kcluster <- cutree(kagnes, k = nclust)
centro <- c(1:(nclust*2))
dim(centro) <- c(nclust,2)
for(i in 1:nclust) {
  centro[i,1] <- mean(sapply(climTOT[kcluster==i,], mean)[1:12])
  centro[i,2] <- mean(sapply(climTOT[kcluster==i,], mean)[13:24])
}
plot(centro,pch=1,ylim=c(5E-08,1.6E-04),xlim=c(250,315), 
     xlab="Average Temp. (K)", ylab="Precipitation flux (kg m-2 s-1)")
par(new=T)
plot(centro[3,1],centro[3,2],col="blue", pch=15,ylim=c(5E-08,1.6E-04),
     xlim=c(250,315), xlab="",ylab="")
par(new=T)
plot(centro[44,1],centro[44,2],col="purple", pch=17,ylim=c(5E-08,1.6E-04),
     xlim=c(250,315), xlab="",ylab="")
#
text(centro, c(as.character(1:nclust)), cex=0.6, pos=4, col="red")
title(main = "Average precipitation vs. average temperature for each cluster",
      cex.main=0.7)
#
#
#
#
#
#
# Analisis de centroides rotados (PCA) conjuntamente para ambos siglos
# solo tomamos en consideracion 4 PCs, que son los que usamos
# para el criterio de agrupamiento
#
kcluster <- cutree(kagnes, k = nclust)
centroPC <- c(1:(nclust*24))
dim(centroPC) <- c(nclust,24)
for(i in 1:nclust) {
  centroPC[i,] <- apply(climTOT.pca$x[kcluster==i,], 2, mean)
}
#
plot(as.data.frame(centroPC[,1:4]))
#
plot(centroPC[,1],centroPC[,2],xlab="PC 1", ylab="PC 2",xlim=c(-10,10),ylim=c(-6,16))
par(new=T)
plot(centroPC[3,1],centroPC[3,2],col="blue", pch=15,xlim=c(-10,10),ylim=c(-6,16), xlab="",ylab="")
par(new=T)
plot(centroPC[44,1],centroPC[44,2],col="purple", pch=17,xlim=c(-10,10),ylim=c(-6,16), xlab="",ylab="")
text(centroPC[,1],centroPC[,2], c(as.character(1:nclust)), cex=0.6, pos=4, col="red")
#
plot(centroPC[,1],centroPC[,3],xlab="PC 1", ylab="PC 3",xlim=c(-10,10),ylim=c(-6,6))
par(new=T)
plot(centroPC[3,1],centroPC[3,3],col="blue", pch=15,xlim=c(-10,10),ylim=c(-6,6), xlab="",ylab="")
par(new=T)
plot(centroPC[44,1],centroPC[44,3],col="purple", pch=17,xlim=c(-10,10),ylim=c(-6,6), xlab="",ylab="")
text(centroPC[,1],centroPC[,3], c(as.character(1:nclust)), cex=0.6, pos=4, col="red")
#
plot(centroPC[,1],centroPC[,4],xlab="PC 1", ylab="PC 4",xlim=c(-10,10),ylim=c(-3,3))
par(new=T)
plot(centroPC[3,1],centroPC[3,4],col="blue", pch=15,xlim=c(-10,10),ylim=c(-3,3), xlab="",ylab="")
par(new=T)
plot(centroPC[44,1],centroPC[44,4],col="purple", pch=17,xlim=c(-10,10),ylim=c(-3,3), xlab="",ylab="")
text(centroPC[,1],centroPC[,4], c(as.character(1:nclust)), cex=0.6, pos=4, col="red")
#
plot(centroPC[,2],centroPC[,3],xlab="PC 2", ylab="PC 3",xlim=c(-6,16),ylim=c(-6,6))
par(new=T)
plot(centroPC[3,2],centroPC[3,3],col="blue", pch=15,xlim=c(-6,16),ylim=c(-6,6), xlab="",ylab="")
par(new=T)
plot(centroPC[44,2],centroPC[44,3],col="purple", pch=17,xlim=c(-6,16),ylim=c(-6,6), xlab="",ylab="")
text(centroPC[,2],centroPC[,3], c(as.character(1:nclust)), cex=0.6, pos=4, col="red")
#
plot(centroPC[,2],centroPC[,4],xlab="PC 2", ylab="PC 4",xlim=c(-6,16),ylim=c(-3,3))
par(new=T)
plot(centroPC[3,2],centroPC[3,4],col="blue", pch=15,xlim=c(-6,16),ylim=c(-3,3), xlab="",ylab="")
par(new=T)
plot(centroPC[44,2],centroPC[44,4],col="purple", pch=17,xlim=c(-6,16),ylim=c(-3,3), xlab="",ylab="")
text(centroPC[,2],centroPC[,4], c(as.character(1:nclust)), cex=0.6, pos=4, col="red")
#
plot(centroPC[,3],centroPC[,4],xlab="PC 3", ylab="PC 4",xlim=c(-6,6),ylim=c(-3,3))
par(new=T)
plot(centroPC[3,3],centroPC[3,4],col="blue", pch=15,xlim=c(-6,6),ylim=c(-3,3), xlab="",ylab="")
par(new=T)
plot(centroPC[44,3],centroPC[44,4],col="purple", pch=17,xlim=c(-6,6),ylim=c(-3,3), xlab="",ylab="")
text(centroPC[,3],centroPC[,4], c(as.character(1:nclust)), cex=0.6, pos=4, col="red")
#
#
# library(rgl)
# plot3d(centroPC[,1],centroPC[,2],centroPC[,3])
# text3d(centroPC[,1],centroPC[,2],centroPC[,3],1:44)
#
#
title(main = "Average precipitation vs. average temperature for each cluster",
      cex.main=0.7)